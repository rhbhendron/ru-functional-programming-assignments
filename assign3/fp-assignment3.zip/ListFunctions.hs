module ListFunctions where

import Prelude hiding (or, and, elem, take, drop)

--and :: [Bool] -> Bool
--or :: [Bool] -> Bool
--elem :: (Eq a) => a -> [a] -> Bool
--drop :: Int -> [a] -> [a]
--take :: Int -> [a] -> [a]
