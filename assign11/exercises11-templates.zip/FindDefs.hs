module FindDefs where

--(?$) :: Maybe (a -> b) -> Maybe a -> Maybe b

--pair :: (Applicative f) => f a -> f b -> f (a,b)

--apply :: [a -> b] -> a -> [b]

--apply2nd :: [a -> b -> c] -> b -> [a -> c]
