module FindDefs where

--sayIO     :: IO Int -> IO String

--sayMaybe  :: Maybe Int -> Maybe String

--mpair     :: (Monad m) => m a -> m b -> m (a,b)

--weirdBind :: (Monad m) => Maybe (m a) -> (a -> m b) -> m (Maybe b)
