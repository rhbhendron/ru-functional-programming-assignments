module FindDefs where

--bindSt  :: (a -> s -> (b,s)) -> (s -> (a,s)) -> (s -> (b,s))

--andThen  :: ((a -> r) -> r) -> ((b -> r) -> a -> r) -> (b -> r) -> r
