module Swap where

-- swap :: (Int, Int) -> (Int, Int)

